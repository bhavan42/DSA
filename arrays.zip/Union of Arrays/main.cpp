#include <iostream>
#include <vector>
using namespace std;

vector<int> sortedArray(vector<int> a, vector<int> b) {
    int i = 0, j = 0;
    vector<int> unionarr;

    while (i < a.size() && j < b.size()) {
        if (a[i] <= b[j]) {
            if (unionarr.empty() || unionarr.back() != a[i])
                unionarr.push_back(a[i]);
            i++;
        } else {
            if (unionarr.empty() || unionarr.back() != b[j])
                unionarr.push_back(b[j]);
            j++;
        }
    }

    while (i < a.size()) {
        if (unionarr.empty() || unionarr.back() != a[i])
            unionarr.push_back(a[i]);
        i++;
    }

    while (j < b.size()) {
        if (unionarr.empty() || unionarr.back() != b[j])
            unionarr.push_back(b[j]);
        j++;
    }

    return unionarr;
}

int main() {
    int n1, n2;
    cin >> n1;

    vector<int> a(n1);
    for (int i = 0; i < n1; i++)
        cin >> a[i];

    cin >> n2;
    vector<int> b(n2);
    for (int i = 0; i < n2; i++)
        cin >> b[i];

    vector<int> result = sortedArray(a, b);

    for (int x : result)
        cout << x << " ";

    return 0;
}
